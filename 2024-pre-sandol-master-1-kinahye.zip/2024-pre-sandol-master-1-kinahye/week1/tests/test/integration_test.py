#if __name__ == '__main__':
#    from sys import path
#    import os
#
#    path.append(os.path.dirname(__file__))

import os
from week1.business_dev.main import app_main
from unittest import TestCase
import json

TEST_JSON_PATH = os.path.join(
    os.path.dirname(os.path.realpath(__file__)),
    "../..",
    "resource",
    "RawSubwayArrival.json"
)


class Test(TestCase):
    def setUp(self):
        with open(TEST_JSON_PATH, "r", encoding = "utf-8") as f:
            self.given_data = json.load(f)

    def test_app_main(self):
        given = app_main(self.given_data)
        # expected_keys = ['당고개행 - 신길온천방면', '왕십리행 - 신길온천방면', '오이도행 - 오이도방면', '인천행 - 오이도방면']
        # self.assertEqual(list(given.get('result', {}).keys()), expected_keys)

        if 'result' not in given:
            self.assertEqual(given['status'], '[Error] 데이터를 받아오지 못했습니다.')
        else:
            expected_keys = ['당고개행 - 신길온천방면', '왕십리행 - 신길온천방면', '오이도행 - 오이도방면', '인천행 - 오이도방면']
            self.assertEqual(list(given.get('result', {}).keys()), expected_keys)



    def test_status_code(self):
        test_json = {"status": 500, "code": "INFO-200", "message": "해당하는 데이터가 없습니다.", "link": "",
                     "developerMessage": "", "total": 0}

        given = app_main(test_json)
        self.assertEqual(given['status'], "[Error] 데이터를 받아오지 못했습니다.")