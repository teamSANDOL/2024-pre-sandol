import json
FILE_PATH = r"C:\Users\hp\Desktop\sandol\2024-pre-sandol-master\week1\resource\RawSubwayArrival.json"
# http://swopenapi.seoul.go.kr/api/subway/sample/json/realtimeStationArrival/0/5/%EC%A0%95%EC%99%95

def load_data() -> json:
    result = ""
    return json.loads(result)
