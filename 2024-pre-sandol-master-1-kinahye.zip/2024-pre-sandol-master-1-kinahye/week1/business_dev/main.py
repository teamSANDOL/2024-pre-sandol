
def app_main(data: dict) -> dict:
    result = {}

    # data에 'result' 키가 없으면 에러 메시지 반환
    if 'result' not in data:
        result['status'] = '[Error] 데이터를 받아오지 못했습니다.'
        return result

    # data에 'result'가 공백이면 에러 메시지 반환
    arrival_info = data['result']
    if not arrival_info:
        result['status'] = '[Error] 도착 정보가 없습니다.'
        return result

    # 'result'와 'status'만 반환
    result['result'] = arrival_info
    result['status'] = data.get('status', 'success')
    return result

if __name__ == "__main__":
    data = {
        "result": {
            "당고개행 - 신길온천방면": [
                "전역 도착"
            ],
            "오이도행 - 오이도방면": [
                "정왕 진입"
            ],
            "왕십리행 - 신길온천방면": [
                "[10]번째 전역 (송도)"
            ],
            "인천행 - 오이도방면": [
                "[3]번째 전역 (초지)"
            ]
        },
        "status": "success"
    }
    res = app_main(data)
    print(res)
